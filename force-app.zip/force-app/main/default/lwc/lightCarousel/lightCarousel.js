import { LightningElement } from 'lwc';

export default class LightCarousel extends LightningElement {}